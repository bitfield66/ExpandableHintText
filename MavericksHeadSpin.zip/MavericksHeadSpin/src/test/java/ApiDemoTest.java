import com.framework.BaseTestClass;
import framework.TestData;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import org.testng.annotations.Test;
import pageObjects.HomePage;
import pageObjects.Preferences;

import java.io.IOException;

public class ApiDemoTest extends BaseTestClass {

    @Test(dataProvider = "InputData", dataProviderClass = TestData.class)
    public void apiDemoTest(String input) {
        AndroidDriver<AndroidElement> driver = (AndroidDriver<AndroidElement>) getDriver();
        createTest("init");
        HomePage h = new HomePage(driver);
        h.Preferences.click();
        Preferences p = new Preferences(driver);
        p.dependencies.click();
        flush();
    }
}


