package com.framework.driver;

public class TestParameters {
    AppiumPlatForm appiumPlatForm;
    String applicationName;
    String deviceName;
}
