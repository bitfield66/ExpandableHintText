package com.framework;

import com.framework.driver.MavericksDriver;
import com.framework.reports.ReportManager;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import java.io.File;
import java.io.IOException;
import java.net.ServerSocket;

public class BaseTestClass {
    private AppiumDriverLocalService service;
    private ReportManager extentReporterNG;

    @BeforeSuite(alwaysRun = true)
    public void beforeSuite() {
        extentReporterNG = new ReportManager();
        extentReporterNG.setUpReport();
    }

    public BaseTestClass() {
        service = startServer();
    }

    @AfterSuite
    public void afterSuite() {
        if (service != null) {
            service.stop();
        }
    }

    public AppiumDriverLocalService startServer() {
        boolean flag = checkIfServerIsRunning(4723);
        if (!flag) {
            service = AppiumDriverLocalService.buildDefaultService();
            service.start();
        }
        return service;
    }

    public boolean checkIfServerIsRunning(int port) {

        boolean isServerRunning = false;
        ServerSocket serverSocket;
        try {
            serverSocket = new ServerSocket(port);

            serverSocket.close();
        } catch (IOException e) {
            //If control comes here, then it means that the port is in use
            isServerRunning = true;
        } finally {
            serverSocket = null;
        }
        return isServerRunning;
    }


    public AppiumDriver getDriver() {
        return MavericksDriver.getInstance().getAppiumDriver();
    }

    public void getScreenshot(String s) throws IOException {
        File scrfile = ((TakesScreenshot) MavericksDriver.getInstance().getAppiumDriver()).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrfile, new File(System.getProperty("user.dir") + "\\" + s + ".png"));
    }

    public void createTest(String testName) {
        extentReporterNG.extent.createTest(testName);
    }

    public void flush() {
        extentReporterNG.extent.flush();
    }
}
