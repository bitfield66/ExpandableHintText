package com.framework.reports;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import org.testng.IReporter;
import org.testng.ISuite;
import org.testng.xml.XmlSuite;

import java.util.List;


public class ReportManager implements IReporter {
    public ExtentReports extent;
    public ExtentHtmlReporter htmlReporter;


    public void setUpReport() {

        htmlReporter = new ExtentHtmlReporter("./Reports/extent.html");
        htmlReporter.config().setDocumentTitle("MavericksHeadSpin Test Automation Report");
        htmlReporter.config().setReportName("MavericksHeadSpin Test Automation Report\"");
        htmlReporter.config().setTheme(Theme.DARK);

        extent = new ExtentReports();
        extent.attachReporter(htmlReporter);
        htmlReporter.config().setTimeStampFormat("dd/MM/yyyy hh:mm:ss a");
    }

    public void generateReport(List<XmlSuite> xmlSuites, List<ISuite> suites, String outputDirectory) {


    }
}