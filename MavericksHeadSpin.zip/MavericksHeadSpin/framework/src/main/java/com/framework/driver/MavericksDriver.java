package com.framework.driver;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

import java.io.File;
import java.io.FileInputStream;
import java.net.URL;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class MavericksDriver {
    public static MavericksDriver mavericksDriver;

    public static MavericksDriver getInstance() {
        if (mavericksDriver == null) {
            mavericksDriver = new MavericksDriver();
        }
        return mavericksDriver;
    }

    public AppiumDriver getAppiumDriver() {
        AppiumDriver appiumDriver = null;

        try {
            FileInputStream fis = new FileInputStream(System.getProperty("user.dir") + "\\resources\\global.properties");
            Properties prop = new Properties();
            prop.load(fis);

            File appDir = new File(System.getProperty("user.dir") + "\\resources");
            File app = new File(appDir, prop.getProperty("applicationName"));

            DesiredCapabilities capabilities = new DesiredCapabilities();
            capabilities.setCapability(MobileCapabilityType.DEVICE_NAME, prop.getProperty("deviceName"));
            capabilities.setCapability(MobileCapabilityType.AUTOMATION_NAME, "uiautomator2");
            capabilities.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 14);
            capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
            appiumDriver = new AndroidDriver(new URL("http://127.0.0.1:4723/wd/hub"), capabilities);
            appiumDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        } catch (Exception e) {
            e.printStackTrace();
        }

        return appiumDriver;
    }
}
