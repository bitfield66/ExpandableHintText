package com.framework.driver;

public enum AppiumPlatForm {
    ANDROID,
    IOS
}
